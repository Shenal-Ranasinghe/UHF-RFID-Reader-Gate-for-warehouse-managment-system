% Design of a lossless matching network with two lumped elements
% Matching a load to a resistive nominal impedance

close all
clear all
clc

% Enter input data
fprintf('Symbols used in the program:\n');
fprintf('Load resistance:        RL\n');
fprintf('Load reactance:         XL\n');
fprintf('Load complex impedance: ZL = RL + j*XL\n');
fprintf('Nominal impedance:      Z0\n');
fprintf('Operating frequency:    f\n\n');

fprintf('Enter input data.\n');
% Load resistance and reactance

r=input('RL[ohm] = ');
if r<=0
  fprintf('Load resistance must be positive.\n');
  return
end

x=input('XL[ohm] = ');

% Nominal impedance

zc=input('Z0[ohm] = ');
if zc<=0
  fprintf('Nominal impedance must be positive.\n');
  return
end

% Operating frequency

f=input(' f[Hz]  = ');
if f<=0
  fprintf('Operating frequency must be positive.\n');
  return
end


% Calculations

fprintf('\n')
w=2*pi*f;
yc=1/zc;
g=r/(r^2+x^2);
b=-x/(r^2+x^2);
opt=0;

if (r==zc)&&(x==0) % at the center, z/zc=1
  fprintf('No matching network required.\n');
  return
end

if r==zc % on the circle r/zc=1
  opt=opt+1; % only series element
  fprintf('\nOPTION %i\n',opt);
  xs=-x;
  if xs<0
    C=-1/(w*xs);
    fprintf('Series capacitance, C=%e F\n',C);
  else
    L=xs/w;
    fprintf('Series inductance, L=%e H\n',L);
  end
  opt=opt+1; % parallel element at load, series at input
  fprintf('\nOPTION %i\n',opt);
  bp1=sqrt(g*(yc-g))-b;
  bp2=-sqrt(g*(yc-g))-b;
  xs1=(b+bp1)/(g^2+(b+bp1)^2);
  xs2=(b+bp2)/(g^2+(b+bp2)^2);
  if not(bp1==0)
    bp=bp1;
    xs=xs1;
  else
    bp=bp2;
    xs=xs2;
  end
  if bp>0
    C=bp/w;
    fprintf('Parallel capacitance at load, C=%e F\n',C);
  elseif bp<0
    L=-1/(w*bp);
    fprintf('Parallel inductance at load, L=%e H\n',L);
  end
  if xs>0
    L=xs/w;
    fprintf('Series inductance at input, L=%e H\n',L);
  elseif xs<0
    C=-1/(w*xs);
    fprintf('Series capacitance at input, C=%e F\n',C);
  end
  return
end

if g==yc % on the circle g/yc=1
  opt=opt+1; % only parallel element
  fprintf('\nOPTION %i\n',opt);
  bp=-b;
  if bp>0
    C=bp/w;
    fprintf('Parallel capacitance, C=%e F\n',C);
  else
    L=-1/(w*bp);
    fprintf('Parallel inductance, L=%e H\n',L);
  end
  opt=opt+1; % series element at load, parallel at input
  fprintf('\nOPTION %i\n',opt);
  xs1=sqrt(r*(zc-r))-x;
  xs2=-sqrt(r*(zc-r))-x;
  bp1=(x+xs1)/(r^2+(x+xs1)^2);
  bp2 = (x + xs2) / (r ^ 2 + (x + xs2) ^ 2);
  if not(xs1==0)
    xs=xs1;
    bp=bp1;
  else
    xs=xs2;
    bp=bp2;
  end
  if xs>0
    L=xs/w;
    fprintf('Series inductance at load, L=%e H\n',L); 
  elseif xs<0
    C=-1/(w*xs);
    fprintf('Series capacitance at load, C=%e F\n',C);
  end
  if bp>0
    C=bp/w;
    fprintf('Parallel capacitance at input, C=%e F\n',C);
  elseif bp<0
    L=-1/(w*bp);
    fprintf('Parallel inductance at input, L=%e H\n',L); 
  end
  return
end

if r<=zc % outside the circle r/zc=1: series element at load, parallel at input
  xs1=sqrt(r*(zc-r))-x;
  xs2=-sqrt(r*(zc-r))-x;
  bp1=(x+xs1)/(r^2+(x+xs1)^2);
  bp2 = (x + xs2) / (r ^ 2 + (x + xs2) ^ 2);
  opt=opt+1;
  fprintf('\nOPTION %i\n',opt);
  if xs1>0
    L=xs1/w;
    fprintf('Series inductance at load, L=%e H\n',L); 
  elseif xs1<0
    C=-1/(w*xs1);
    fprintf('Series capacitance at load, C=%e F\n',C);
  end
  if bp1>0
    C=bp1/w;
    fprintf('Parallel capacitance at input, C=%e F\n',C);
  elseif bp1<0
    L=-1/(w*bp1);
    fprintf('Parallel inductance at input, L=%e H\n',L); 
  end
  opt=opt+1;
  fprintf('\nOPTION %i\n',opt);
  if xs2>0
    L=xs2/w;
    fprintf('Series inductance at load, L=%e H\n',L); 
  elseif xs2<0
    C=-1/(w*xs2);
    fprintf('Series capacitance at load, C=%e F\n',C)
  end
  if bp2>0
    C=bp2/w;
    fprintf('Parallel capacitance at input, C=%e F\n',C);
  elseif bp2<0
    L=-1/(w*bp2);
    fprintf('Parallel inductance at input, L=%e H\n',L); 
  end
end

if g<=yc % outside the circle g/yc=1: parallel element at load, series at input
  bp1=sqrt(g*(yc-g))-b;
  bp2=-sqrt(g*(yc-g))-b;
  xs1=(b+bp1)/(g^2+(b+bp1)^2);
  xs2=(b+bp2)/(g^2+(b+bp2)^2);
  opt=opt+1;
  fprintf('\nOPTION %i\n',opt);
  if bp1>0
    C=bp1/w;
    fprintf('Parallel capacitance at load, C=%e F\n',C);
  elseif bp1<0
    L=-1/(w*bp1);
    fprintf('Parallel inductance at load, L=%e H\n',L);
  end
  if xs1>0
    L=xs1/w;
    fprintf('Series inductance at input, L=%e H\n',L);
  elseif xs1<0
    C=-1/(w*xs1);
    fprintf('Series capacitance at input, C=%e F\n',C);
  end
  opt=opt+1;
  fprintf('\nOPTION %i\n',opt);
  if bp2>0
    C=bp2/w;
    fprintf('Parallel capacitance at load, C=%e F\n',C);
  elseif bp2<0
    L=-1/(w*bp2);
    fprintf('Parallel inductance at load, L=%e H\n',L);
  end
  if xs2>0
    L=xs2/w;
    fprintf('Series inductance at input, L=%e H\n',L);
  elseif xs2<0
    C=-1/(w*xs2);
    fprintf('Series capacitance at input, C=%e F\n',C);
  end
end
return