﻿#define _USE_MATH_DEFINES

#include <iostream>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>

#include <math.h>

void PrintScheme(int top, int LC);
void MatchingNetworkCalculation(double X1, double X2, double B1, double B2, double f, int top);

void main() {
	double RL, XL;																					// Load resistance and reactance;
	double GL, BL;																					// Load conductance and susceptance;
	double f;																						// Operating frequency;
	double Z0, Y0;																					// Nominal impedance and admittance;

	int top;																						// Topology identifier;
	double X1, X2;																					// Matching network reactance;
	double B1, B2;																					// Matching network susceptance;

	char textln[256];
	double zero = 1e-12;

	printf("Symbols used in the program:\n");
	printf("Load resistance:        RL\n");
	printf("Load reactance:         XL\n");
	printf("Load complex impedance: ZL = RL + j*XL\n");
	printf("Nominal impedance:      Z0\n");
	printf("Operating frequency:    f\n\n");

	do {
		X1 = X2 = B1 = B2 = 0.0;
		printf("Enter input data.\n");
		printf("RL[ohm] = ");
		if (scanf("%lf", &RL) < 1) {
			printf("Wrong input.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		printf("XL[ohm] = ");
		if (scanf("%lf", &XL) < 1) {
			printf("Wrong input.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		printf("Z0[ohm] = ");
		if (scanf("%lf", &Z0) < 1) {
			printf("Wrong input.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		if (Z0 <= zero) {
			printf("Nominal impedance must be positive.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		if ((RL / Z0) <= zero) {
			printf("Load resistance must be positive.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		printf(" f[Hz]  = ");
		if (scanf("%lf", &f) < 1) {
			printf("Wrong input.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		if (f <= zero) {
			printf("Operating frequency must be positive.\n");
			printf("Enter z to close or press Enter to continue.\n");
			fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
			continue;
		}
		printf("\n---------------------\n");

		Y0 = 1.0 / Z0;
		GL = RL / (pow(RL, 2.0) + pow(XL, 2.0));
		BL = -XL / (pow(RL, 2.0) + pow(XL, 2.0));

		if ((((RL - Z0) / Z0) < -zero) && ((RL / Z0) > zero) && ((abs(GL - Y0) * Z0) > zero)) {
			top = 1;																					// Serial element toward load.
			// First solution //
			X1 = -XL + sqrt(RL * (Z0 - RL));
			X2 = -(Z0 * RL) / (XL + X1);
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
			// Second solution //
			X1 = -XL - sqrt(RL * (Z0 - RL));
			X2 = -(Z0 * RL) / (XL + X1);
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
		}
		if ((((GL - Y0) * Z0) < -zero) && ((GL * Z0) > zero) && ((abs(RL - Z0) / Z0) > zero)) {
			top = 2;																					// Shunt element toward load.
			// First solution //
			B1 = -BL + sqrt(GL * (Y0 - GL));
			B2 = -(Y0 * GL) / (BL + B1);
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
			// Second solution //
			B1 = -BL - sqrt(GL * (Y0 - GL));
			B2 = -(Y0 * GL) / (BL + B1);
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
		}
		if (((abs(RL - Z0) / Z0) <= zero) && (abs(XL / Z0) > zero)) {
			top = 3;																					// RL = Z0
			// First solution //
			X1 = -XL;
			X2 = 0.0;
			// Second solution //
			B1 = -2.0 * BL;
			B2 = Y0 * GL / BL;
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
		}
		if (((abs(GL - Y0) * Z0) <= zero) && (abs(BL * Z0) > zero)) {
			top = 4;																					// GL = Z0
			// First solution //
			B1 = -BL;
			B2 = 0.0;
			// Second solution //
			X1 = -2.0 * XL;
			X2 = Z0 * RL / XL;
			MatchingNetworkCalculation(X1, X2, B1, B2, f, top);
		}
		if (((abs(RL - Z0) / Z0) <= zero) && (abs(XL / Z0) <= zero)) {
			printf("No matching network required.\n");
		}
		printf("Enter z to close or press Enter to continue.\n");
		fgets(textln, sizeof(textln), stdin); fgets(textln, sizeof(textln), stdin);
		system("cls");
	} while (textln[0] != 'z');
	return;
}

void PrintScheme(int top, int LC) {
	_setmode(_fileno(stdout), _O_U16TEXT);

	switch (top) {
	case 1:
		switch (LC) {
		case 1:
			wprintf(L"  o────┬── C1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     L2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 2:
			wprintf(L"  o────┬── L1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     C2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 3:
			wprintf(L"  o────┬── L1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     L2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 4:
			wprintf(L"  o────┬── C1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     C2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		default:
			break;
		}
		break;
	case 2:
		switch (LC) {
		case 1:
			wprintf(L"  o─── L2 ──┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          C1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 2:
			wprintf(L"  o─── C2 ──┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          L1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 3:
			wprintf(L"  o─── L2 ──┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          L1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 4:
			wprintf(L"  o──── C2 ─┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          C1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		default:
			break;
		}
		break;
	case 3:
		switch (LC) {
		case 1:
			wprintf(L"  o─── L2 ──┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          C1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 2:
			wprintf(L"  o─── C2 ──┬───┐\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"Z0          L1  ZL\n");
			wprintf(L"            │   │\n");
			wprintf(L"            │   │\n");
			wprintf(L"  o─────────┴───┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 3:
			wprintf(L"  o───── C1 ────┐\n");
			wprintf(L"                │\n");
			wprintf(L"                │\n");
			wprintf(L"Z0              ZL\n");
			wprintf(L"                │\n");
			wprintf(L"                │\n");
			wprintf(L"  o─────────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 4:
			wprintf(L"  o───── L1 ────┐\n");
			wprintf(L"                │\n");
			wprintf(L"                │\n");
			wprintf(L"Z0              ZL\n");
			wprintf(L"                │\n");
			wprintf(L"                │\n");
			wprintf(L"  o─────────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		default:
			break;
		}
		break;
	case 4:
		switch (LC) {
		case 1:
			wprintf(L"  o────┬── C1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     L2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 2:
			wprintf(L"  o────┬── L1 ──┐\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"Z0     C2       ZL\n");
			wprintf(L"       │        │\n");
			wprintf(L"       │        │\n");
			wprintf(L"  o────┴────────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 3:
			wprintf(L"  o───────┬─────┐\n");
			wprintf(L"          │     │\n");
			wprintf(L"          │     │\n");
			wprintf(L"Z0        C1    ZL\n");
			wprintf(L"          │     │\n");
			wprintf(L"          │     │\n");
			wprintf(L"  o───────┴─────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		case 4:
			wprintf(L"  o───────┬─────┐\n");
			wprintf(L"          │     │\n");
			wprintf(L"          │     │\n");
			wprintf(L"Z0        L1    ZL\n");
			wprintf(L"          │     │\n");
			wprintf(L"          │     │\n");
			wprintf(L"  o───────┴─────┘\n");
			wprintf(L"\n---------------------\n");
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	_setmode(_fileno(stdout), _O_TEXT);
	return;
}

void MatchingNetworkCalculation(double X1, double X2, double B1, double B2, double f, int top) {
	double w;																						// Angular frequency.
	double L1, L2, C1, C2;																			// Matching network inductance and capacitance;
	int LC;																							// Specific case identifier;
	w = 2.0 * M_PI * f;

	switch (top) {
	case 1:
		if (X1 > 0) {
			L1 = X1 / w;
			printf("L1 = %11.5e H\n", L1);
			if (X2 > 0) {
				L2 = X2 / w;
				printf("L2 = %11.5e H\n", L2);
				LC = 3;
				PrintScheme(top, LC);
			}
			if (X2 < 0) {
				C2 = -1.0 / (w * X2);
				printf("C2 = %11.5e F\n", C2);
				LC = 2;
				PrintScheme(top, LC);
			}
		}
		if (X1 < 0) {
			C1 = -1.0 / (w * X1);
			printf("C1 = %11.5e F\n", C1);
			if (X2 > 0) {
				L2 = X2 / w;
				printf("L2 = %11.5e H\n", L2);
				LC = 1;
				PrintScheme(top, LC);
			}
			if (X2 < 0) {
				C2 = -1.0 / (w * X2);
				printf("C2 = %11.5e F\n", C2);
				LC = 4;
				PrintScheme(top, LC);
			}
		}
		break;
	case 2:
		if (B1 > 0) {
			C1 = B1 / w;
			printf("C1 = %11.5e F\n", C1);
			if (B2 > 0) {
				C2 = B2 / w;
				printf("C2 = %11.5e F\n", C2);
				LC = 4;
				PrintScheme(top, LC);
			}
			if (B2 < 0) {
				L2 = -1.0 / (w * B2);
				printf("L2 = %11.5e H\n", L2);
				LC = 1;
				PrintScheme(top, LC);
			}
		}
		if (B1 < 0) {
			L1 = -1.0 / (w * B1);
			printf("L1 = %11.5e H\n", L1);
			if (B2 > 0) {
				C2 = B2 / w;
				printf("C2 = %11.5e F\n", C2);
				LC = 2;
				PrintScheme(top, LC);
			}
			if (B2 < 0) {
				L2 = -1.0 / (w * B2);
				printf("L2 = %11.5e H\n", L2);
				LC = 3;
				PrintScheme(top, LC);
			}
		}
		break;
	case 3:
		if (X1 < 0) {
			C1 = -1.0 / (w * X1);
			printf("C1 = %11.5e F\n", C1);
			LC = 3;
			PrintScheme(top, LC);
		}
		if (X1 > 0) {
			L1 = X1 / w;
			printf("L1 = %11.5e H\n", L1);
			LC = 4;
			PrintScheme(top, LC);
		}
		if (B1 > 0) {
			C1 = B1 / w;
			printf("C1 = %11.5e F\n", C1);
			L2 = -1.0 / (w * B2);
			printf("L2 = %11.5e H\n", L2);
			LC = 1;
			PrintScheme(top, LC);
		}
		if (B1 < 0) {
			L1 = -1.0 / (w * B1);
			printf("L1 = %11.5e H\n", L1);
			C2 = B2 / w;
			printf("C2 = %11.5e F\n", C2);
			LC = 2;
			PrintScheme(top, LC);
		}
		break;
	case 4:
		if (B1 > 0) {
			C1 = B1 / w;
			printf("C1 = %11.5e F\n", C1);
			LC = 3;
			PrintScheme(top, LC);
		}
		if (B1 < 0) {
			L1 = -1.0 / (w * B1);
			printf("L1 = %11.5e H\n", L1);
			LC = 4;
			PrintScheme(top, LC);
		}
		if (X1 < 0) {
			C1 = -1.0 / (w * X1);
			printf("C1 = %11.5e F\n", C1);
			L2 = X2 / w;
			printf("L2 = %11.5e H\n", L2);
			LC = 1;
			PrintScheme(top, LC);
		}
		if (X1 > 0) {
			L1 = X1 / w;
			printf("L1 = %11.5e H\n", L1);
			C2 = -1.0 / (w * X2);
			printf("C2 = %11.5e F\n", C2);
			LC = 2;
			PrintScheme(top, LC);
		}
		break;
	default:
		break;
	}
}